import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import NavAuth from "../components/NavAuth";
import Footer from "@/components/Footer";
import { AuthProvider } from "@/context/AuthContext";
import LenisGsapContext from "@/context/LenisGsapContext";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "POS System",
  description: "POS System with JWT Authentication and PostgreSQL Database",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased min-h-screen`}
      >
        <AuthProvider>
          <LenisGsapContext>
            <nav className="w-full h-1/5 bg-neutral-black text-neutral-white flex items-center justify-center">
              <NavAuth />
            </nav>

            <div className="relative w-full h-full bg-neutral-black text-neutral-white flex flex-col items-center z-10 overflow-hidden">
              {children}
            </div>

            <footer className="w-full min-h-[30vh] flex items-center justify-around md:sticky md:bottom-0 bg-neutral-gray text-neutral-surface">
              <Footer />
            </footer>
          </LenisGsapContext>
        </AuthProvider>
      </body>
    </html>
  );
}
